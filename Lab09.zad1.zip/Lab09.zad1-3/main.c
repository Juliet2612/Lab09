#include <stdio.h>
#include <windows.h>
int a;
void f1(void) {
    int k = 0;
    register float x = 2.0f;
    int a = 1;
    k++;
    a++;
    x += 2.0f;
    printf("\nk: %d\tx: %f\ta: %d", k, x, a);
}
void f2(void) {
    static int j = 0;
    j++;
    a++;
    printf("\nj: %d", j);
}
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    register int b = a + 1;
    printf("Zmienna globalna a: %d\n", a);
    printf("Zmienna lokalna rejestrowa b: %d\n", b);
    for (int i = 0; i < 5; i++) {
        f1();
    }
    printf("\n");
    for (int i = 0; i < 5; i++) {
        f2();
    }
    printf("\n\nZmienna globalna a: %d\n", a);
    printf("Zmienna lokalna rejestrowa b: %d\n", b);
    fflush(stdin);
    getchar();
    return 0;
}