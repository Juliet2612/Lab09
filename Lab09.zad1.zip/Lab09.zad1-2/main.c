#include <stdio.h>
#include <windows.h>

void swap(int *, int *);
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    printf("Funkcja swap() - wersja poprawna!\n");
    int i = 20, j = 30;
    printf("\nPrzed wywołaniem swap(): i = %d, j = %d\n", i, j);
    swap(&i, &j);
    printf("Po wywołaniu swap(): i = %d, j = %d\n", i, j);
    fflush(stdin);
    getchar();
    return 0;
}
void swap(int *var1, int *var2) {
    int tmp = *var1;
    *var1 = *var2;
    *var2 = tmp;
}