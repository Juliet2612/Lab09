#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "myfun.h"
void minmax(const int *tab, int n, int *min, int *max) {
    int mmin = tab[0];
    int mmax = tab[0];
    for (int i = 1; i < n; i++) {
        if (mmin > tab[i]) mmin = tab[i];
        if (tab[i] > mmax) mmax = tab[i];
    }
    *min = mmin;
    *max = mmax;
}
void printArray(const int *tab, int n) {
    for (int i = 0; i < n; i++) {
        printf("%3d", tab[i]);
    }
    printf("\n");
}
void genArray(int *tab, int n, int range) {
    time_t tt;
    int sieve = time(&tt);
    srand(sieve);
    for (int i = 0; i < n; i++) {
        tab[i] = rand() % range;
    }
}