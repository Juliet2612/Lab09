#define MYSIZE 15
#define MYRANGE 100
void minmax(const int *tab, int n, int *min, int *max);
void printArray(const int *tab, int n);
void genArray(int *tab, int n, int range);