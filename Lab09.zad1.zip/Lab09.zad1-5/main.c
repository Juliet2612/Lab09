#include <stdio.h>
#include "myfun.h"
#include <windows.h>
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    int mini, maxi;
    int mytab[MYSIZE];
    genArray(mytab, MYSIZE, MYRANGE);
    printArray(mytab, MYSIZE);
    minmax(mytab,MYSIZE, &mini, &maxi);
    printf("\nPrzykład 1\n\tmin: %d, max: %d\n", mini, maxi);
    minmax(mytab + 3, 5, &mini, &maxi);
    printf("\nPrzykład 2\n\tmin: %d, max: %d\n", mini, maxi);
    fflush(stdin);
    getchar();
    printf("\n\n");
    return 0;
}