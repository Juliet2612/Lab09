#include <stdio.h>
#include <windows.h>
#define COUNT 3
int myMin(int, int, int);
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    int i, j, k;
    for (int n = 0; n < COUNT; n++) {
        printf("\nPodaj 3 liczby całkowite oddzielone przecinkami: ");
        scanf("%d,%d,%d", &i, &j, &k);
        printf("Miniumum z (%d, %d, %d) to %d\n", i, j, k, myMin(i, j, k));
    }
    fflush(stdin);
    getchar();
    return 0;
}
int myMin(int a, int b, int c) {
    int minAB = (a <= b) ? a : b;
    return (minAB <= c) ? minAB : c;
}