#include <stdio.h>
#include "myfun.h"
#include <windows.h>
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    int dane1[10] = {1, -2, 3, -4, 5, -6, 7};
    int dane2[] = {-1, 3, -5, 7, -9, 11, -13, +15, -17};
    int dl2 = sizeof(dane2) / sizeof(int);

    printf("\nPrzykład 1 - 'dane1'\n");
    printArray(dane1, TABSIZE);
    printf("\nSuma1: %d", sumArray(dane1, TABSIZE));
    printf("\n\nPrzykład 2 - 'dane2'\n");
    printArray(dane2, dl2);
    printf("\nSuma2: %d", sumArray(dane2, dl2));
    printf("\n\nPrzykład 3 - początkowe 4 elem. z 'dane1'\n");
    printArray(dane1, 4);
    printf("\nSuma3: %d", sumArray(dane1, 4));
    printf("\n\nPrzykład 4 - wycinek o indeksach [3..7] z 'dane2'\n");
    printArray(dane2 + 3, 5); //wywoł. funkcji
    printf("\nSuma4: %d", sumArray(dane2 + 3, 5));
    fflush(stdin);
    printf("\n\nNaciśnij Enter, aby zakończyć\n");
    getchar();
    return 0;
}