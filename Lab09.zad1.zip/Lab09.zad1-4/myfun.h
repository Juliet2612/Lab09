#define TABSIZE 10
int sumArray(const int *, int);
void printArray(const int *, int);