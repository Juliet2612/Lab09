#include <stdio.h>
int sumArray(const int *tab, int size) {
    int result = 0;
    for (int i = 0; i < size; i++) {
        if (tab[i] > 0) result += tab[i];
    }
    return result;
}
void printArray(const int *tab, int size) {
    for (int i = 0; i < size; i++) {
        printf("%5d", tab[i]);
    }
}